

APP FUNCTIONALITY:
The purpose of this repository is to hold the Disaster Alleviation Foundation C# Website.

The application holds the following functionalities:
- Runs the database connection to my Azure SQL Database through SSMS
- Allows users to login, register and edit their profile or delete it
- Allows users to volunteer and for volunteers to be assigned roles (tasks to do at incident sites)
- Incident reporting (Incident Name, Serverity type, description and imaging)
- Allows users to donate (type of donations and quanitity)
- Has user friendly design
- About us to describe what the foundation is about
- Dashboards on home to track the amout of volunteers, donations and incidents reported

App flow:
- Home Page (Index):
   -Navigation:
    -Register/Login - Profile edits
    -Volunteer : Register as volunteer
    -Admin login - Manage volunteer and volunteer tasks
    - Donation - submit donation
    - Disaster - report disaster (details)

Explaination of models: 
In this application, models in C# (classes in the Models folder) represent the structure of the data we work with in the code. Each model corresponds to a database table in Azure SQL:


PART 3 UPDATES:
Testing phase and deployment,
- The rest of this project contains testing to allow for the deployment of the application on azure web app.
- This project contains:
- Unit tests = testing of models
- Integration tests = testing on controllers and database integration connections
- UI tests = testing of user interfaces *views*
- As well as load tests and stress testing using apache jmeter
- and automated testing to allow final deployment
